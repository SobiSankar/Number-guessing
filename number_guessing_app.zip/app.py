from flask import Flask, render_template, request, redirect, url_for, session
import random

app = Flask(__name__)
app.secret_key = 'replace-with-a-secure-random-key'

MAX_ATTEMPTS = 10

@app.route('/', methods=['GET', 'POST'])
def index():
    if 'number' not in session:
        session['number'] = random.randint(1, 100)
        session['attempts'] = 0
        session['message'] = 'Guess a number between 1 and 100.'

    if request.method == 'POST':
        if 'reset' in request.form:
            session.pop('number', None)
            session.pop('attempts', None)
            session.pop('message', None)
            return redirect(url_for('index'))

        guess_raw = request.form.get('guess', '').strip()
        if not guess_raw.isdigit():
            session['message'] = 'Please enter a valid integer.'
            return redirect(url_for('index'))

        guess = int(guess_raw)
        session['attempts'] = session.get('attempts', 0) + 1

        if session['attempts'] > MAX_ATTEMPTS:
            session['message'] = f"Out of attempts! The number was {session['number']}."
            return redirect(url_for('index'))

        secret = session['number']
        if guess < secret:
            session['message'] = 'Too low!'
        elif guess > secret:
            session['message'] = 'Too high!'
        else:
            session['message'] = f'Correct! You guessed it in {session["attempts"]} attempts.'

        return redirect(url_for('index'))

    return render_template('index.html', message=session.get('message', ''), attempts=session.get('attempts', 0), max_attempts=MAX_ATTEMPTS)

if __name__ == '__main__':
    app.run(debug=True)
